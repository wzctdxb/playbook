<?php

/** @generate-class-entries */

function ctype_alnum(mixed $text): bool {}

function ctype_alpha(mixed $text): bool {}

function ctype_cntrl(mixed $text): bool {}

function ctype_digit(mixed $text): bool {}

function ctype_lower(mixed $text): bool {}

function ctype_graph(mixed $text): bool {}

function ctype_print(mixed $text): bool {}

function ctype_punct(mixed $text): bool {}

function ctype_space(mixed $text): bool {}

function ctype_upper(mixed $text): bool {}

function ctype_xdigit(mixed $text): bool {}
